package com.consultation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@EnableAutoConfiguration
@ComponentScan({ "com.consultation", "com.consultation.entites" })

@SpringBootApplication
public class TestEmbaucheApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestEmbaucheApplication.class, args);
	}

}
