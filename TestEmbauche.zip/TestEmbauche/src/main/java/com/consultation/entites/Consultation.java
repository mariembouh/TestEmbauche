package com.consultation.entites;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data @AllArgsConstructor @NoArgsConstructor @ToString
@Entity
public class Consultation {
	@Id 
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String Nom;
	private String Prenom;
	private Date DateNaissance;
	private String Genre;
	private String Image;
	private String GrpSanguin;
	private double Poids;
	private double Taille;
	private String Observation;
	
	
	/*public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNom() {
		return Nom;
	}
	public void setNom(String nom) {
		Nom = nom;
	}
	public String getPrenom() {
		return Prenom;
	}
	public void setPrenom(String prenom) {
		Prenom = prenom;
	}
	public Date getDateNaissance() {
		return DateNaissance;
	}
	public void setDateNaissance(Date dateNaissance) {
		DateNaissance = dateNaissance;
	}
	public String getGenre() {
		return Genre;
	}
	public void setGenre(String genre) {
		Genre = genre;
	}
	public String getImage() {
		return Image;
	}
	public void setImage(String image) {
		Image = image;
	}
	public String getGrpSanguin() {
		return GrpSanguin;
	}
	public void setGrpSanguin(String grpSanguin) {
		GrpSanguin = grpSanguin;
	}
	public double getPoids() {
		return Poids;
	}
	public void setPoids(double poids) {
		Poids = poids;
	}
	public double getTaille() {
		return Taille;
	}
	public void setTaille(double taille) {
		Taille = taille;
	}
	public String getObservation() {
		return Observation;
	}
	public void setObservation(String observation) {
		Observation = observation;
	}
	@Override
	public String toString() {
		return "Consultation [id=" + id + ", Nom=" + Nom + ", Prenom=" + Prenom + ", DateNaissance=" + DateNaissance
				+ ", Genre=" + Genre + ", Image=" + Image + ", GrpSanguin=" + GrpSanguin + ", Poids=" + Poids
				+ ", Taille=" + Taille + ", Observation=" + Observation + "]";
	}
	public Consultation(String nom, String prenom, Date dateNaissance, String genre, String image, String grpSanguin,
			double poids, double taille, String observation) {
		super();
		Nom = nom;
		Prenom = prenom;
		DateNaissance = dateNaissance;
		Genre = genre;
		Image = image;
		GrpSanguin = grpSanguin;
		Poids = poids;
		Taille = taille;
		Observation = observation;
	}
	public Consultation() {
		super();
		// TODO Auto-generated constructor stub
	}*/
	
	
	
	
}
