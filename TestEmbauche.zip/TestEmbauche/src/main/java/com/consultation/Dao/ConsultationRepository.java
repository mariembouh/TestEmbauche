package com.consultation.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.consultation.entites.Consultation;

public interface ConsultationRepository extends JpaRepository<Consultation, Long> {
	@Query("select c from Consultation c where c.id like :x")
	public Consultation findByIdConslt(@Param("x") Long id);
}
