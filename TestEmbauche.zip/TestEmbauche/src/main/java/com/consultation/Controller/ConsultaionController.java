package com.consultation.Controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.consultation.Dao.ConsultationRepository;
import com.consultation.entites.Consultation;



@Controller
public class ConsultaionController {
	public static String uploadDirectory = System.getProperty("user.dir")+"/images";
	
	@Autowired
	private ConsultationRepository consultationRepository;
	
	//liste des consultations
	@RequestMapping(value="/accueil")
	public String index(Model model) {
		model.addAttribute("consulations",consultationRepository.findAll());
		return "Consultations";
	}
	
	//Formulaire d'ajout d'une consultation
	@RequestMapping(value="/AjouterConsultation")
	public String FormAjoutConsultation(Model model) {
		return "AjouterConsultation"; 
	}

	//Sauvegarder  une consultation
	@RequestMapping(value="/saveConsultation")
	public String saveConsultation(Model model, @Valid Consultation consultation,
			MultipartFile files, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "AjouterConsultation";
		}
		else {

			 StringBuilder fileNames = new StringBuilder();
			  MultipartFile file = files;
			  Path fileNameAndPath = Paths.get(uploadDirectory, file.getOriginalFilename());
			  fileNames.append(file.getOriginalFilename());
			  try {
				Files.write(fileNameAndPath, file.getBytes());
			
				consultation.setImage(fileNames.toString());
				consultationRepository.save(consultation);
			  } catch (IOException e) {
				e.printStackTrace();
				return "AjouterConsultation";
			  }
			  
			  return "redirect:/accueil";		
				
		}	  
		 
	}


	//Supprimer  une consultation
	@RequestMapping(value="/SupprimerConsultation")
	public String SupprimerConsultation(Long id) {
	consultationRepository.deleteById(id);
		return "redirect:/accueil";		

	}


	//Formulaire de modification  d'une consultation
	@RequestMapping(value="/ModifierConsultation")
	public String ModifierConsultation(Model model, Long id) {
		model.addAttribute("consultation",consultationRepository.findById(id).get());
		return "ModifierConsultation";		

	}

}
